//
//  Vanflex_4Tests.swift
//  Vanflex 4Tests
//
//  Created by Brian Nangle on 29/04/2025.
//

import Testing
@testable import Vanflex_4

struct Vanflex_4Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
